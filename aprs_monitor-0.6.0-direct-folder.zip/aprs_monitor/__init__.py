"""APRS Monitor integration setup."""

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from . import binary_sensor as binary_sensor
from . import device_tracker as device_tracker
from . import event as event
from . import sensor as sensor
from .const import (
    CONF_API_KEY,
    CONF_CALLSIGNS,
    CONF_HOME_RADIUS,
    CONF_MAX_POSITION_AGE,
    CONF_MOVEMENT_SPEED_THRESHOLD,
    CONF_UPDATE_INTERVAL,
    DEFAULT_HOME_RADIUS,
    DEFAULT_MAX_POSITION_AGE,
    DEFAULT_MOVEMENT_SPEED_THRESHOLD,
    DEFAULT_UPDATE_INTERVAL,
    DOMAIN,
    PLATFORMS,
)
from .coordinator import AprsMonitorCoordinator
from .device_cleanup import should_remove_aprs_device


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    """Set up the APRS Monitor component."""
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up APRS Monitor from a config entry."""
    callsigns = entry.options.get(CONF_CALLSIGNS, entry.data[CONF_CALLSIGNS])
    update_interval = entry.options.get(CONF_UPDATE_INTERVAL, DEFAULT_UPDATE_INTERVAL)
    max_position_age = entry.options.get(CONF_MAX_POSITION_AGE, DEFAULT_MAX_POSITION_AGE)
    home_radius = entry.options.get(CONF_HOME_RADIUS, DEFAULT_HOME_RADIUS)
    movement_speed_threshold = entry.options.get(
        CONF_MOVEMENT_SPEED_THRESHOLD,
        DEFAULT_MOVEMENT_SPEED_THRESHOLD,
    )
    coordinator = AprsMonitorCoordinator(
        hass,
        entry,
        async_get_clientsession(hass),
        entry.data[CONF_API_KEY],
        tuple(callsigns),
        int(update_interval),
        int(max_position_age),
        float(home_radius),
        float(movement_speed_threshold),
    )
    await coordinator.async_config_entry_first_refresh()

    _remove_stale_devices(hass, entry, set(callsigns))

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload an APRS Monitor config entry."""
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        hass.data[DOMAIN].pop(entry.entry_id)
    return unloaded


async def async_remove_config_entry_device(
    hass: HomeAssistant,
    entry: ConfigEntry,
    device_entry: dr.DeviceEntry,
) -> bool:
    """Allow removal only after a callsign was removed from configuration."""
    callsigns = entry.options.get(CONF_CALLSIGNS, entry.data[CONF_CALLSIGNS])
    return should_remove_aprs_device(device_entry.identifiers, callsigns)


def _remove_stale_devices(
    hass: HomeAssistant,
    entry: ConfigEntry,
    configured_callsigns: set[str],
) -> None:
    """Remove devices that are certainly absent from the configured callsigns."""
    registry = dr.async_get(hass)
    for device in dr.async_entries_for_config_entry(registry, entry.entry_id):
        if should_remove_aprs_device(device.identifiers, configured_callsigns):
            registry.async_update_device(
                device.id,
                remove_config_entry_id=entry.entry_id,
            )
